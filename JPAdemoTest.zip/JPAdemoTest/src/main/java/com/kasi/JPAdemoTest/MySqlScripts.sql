create database studentDb;

use studentDb;

show tables;

select * from student;