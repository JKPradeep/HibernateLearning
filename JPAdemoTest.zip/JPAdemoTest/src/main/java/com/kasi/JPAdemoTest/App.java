/**
 * 
 */
package com.kasi.JPAdemoTest;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * @author JK Pradeep
 *
 */
public class App {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu1");
		EntityManager em = emf.createEntityManager();
		
		
		Student s = new Student();
		s.setRollNo(1002);
		s.setName("KasiJ");
		s.setMarks(40);
		
		
		Student s1 = new Student();
		s1.setRollNo(1003);
		s1.setName("PradeepJ");
		s1.setMarks(49);
		
		Student s2 = new Student();
		s2.setRollNo(1005);
		s2.setName("JallJ");
		s2.setMarks(46);
		
		
		em.getTransaction().begin();
		em.persist(s);
		em.persist(s1);
		em.persist(s2);
		em.getTransaction().commit();
		
		Student s3 = em.find(Student.class, 1003);
			
		System.out.println(s3);
	}

}
