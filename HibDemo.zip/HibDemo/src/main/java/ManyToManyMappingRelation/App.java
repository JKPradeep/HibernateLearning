/**
 * 
 */
package ManyToManyMappingRelation;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;


/**
 * @author JK Pradeep
 *
 */
public class App {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Student stud1 = new Student();
		stud1.setRollNo(301);
		stud1.setName("kasi");
		stud1.setMarks(40);
		
		Student stud2 = new Student();
		stud2.setRollNo(401);
		stud2.setName("Pradeep");
		stud2.setMarks(60);
		
		Student stud3 = new Student();
		stud3.setRollNo(501);
		stud3.setName("Jalla");
		stud3.setMarks(80);
		
		
		Laptop laptop1 = new Laptop();
		laptop1.setlId(1001);
		laptop1.setlName("dell");
		
		Laptop laptop2 = new Laptop();
		laptop2.setlId(1002);
		laptop2.setlName("hp");

		Laptop laptop3 = new Laptop();
		laptop3.setlId(1005);
		laptop3.setlName("Lenovo");
		
		Laptop laptop4 = new Laptop();
		laptop4.setlId(1006);
		laptop4.setlName("apple");
		
	
		List<Laptop> laptops1 = new ArrayList<Laptop>();
		laptops1.add(laptop4);
		laptops1.add(laptop3);
		
		stud3.setLaptopsw(laptops1);
		
		
		List<Student> students1 = new ArrayList<Student>();
		students1.add(stud1);
		students1.add(stud2);
		laptop2.setStudts(students1);

		
		Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Laptop.class).addAnnotatedClass(Student.class);	
		ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
		SessionFactory sf = con.buildSessionFactory(reg);
		Session session = sf.openSession();
		
		Transaction tx = session.beginTransaction();

		session.save(laptop2);

		session.save(stud3);

		tx.commit();
		
	}

}
