/**
 * 
 */
package oneToOneMappingRelation;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * @author JK Pradeep
 *
 */

@Entity
public class Laptop {

	@Id
	private int lId;
	
	private String lName;

	
	
	
	public int getlId() {
		return lId;
	}

	public void setlId(int lId) {
		this.lId = lId;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}


}
