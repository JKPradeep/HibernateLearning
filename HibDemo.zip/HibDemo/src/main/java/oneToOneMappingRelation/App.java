/**
 * 
 */
package oneToOneMappingRelation;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

/**
 * @author JK Pradeep
 *
 */
public class App {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Laptop laptop = new Laptop();
		
		laptop.setlId(1001);
		laptop.setlName("dell1");
		
		
		Student stud = new Student();
		
		stud.setRollNo(300);
		stud.setName("kasi");
		stud.setMarks(40);
		stud.setLaptopw(laptop);
		

		Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Laptop.class).addAnnotatedClass(Student.class);	
		ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
		SessionFactory sf = con.buildSessionFactory(reg);
		Session session = sf.openSession();
		
		Transaction tx = session.beginTransaction();
		
		session.save(laptop);		
		session.save(stud);

		tx.commit();
		
	}

}
