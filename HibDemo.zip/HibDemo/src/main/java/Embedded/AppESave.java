package Embedded;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;



/**
 * Hello world!
 *
 */
public class AppESave 
{
    public static void main( String[] args )
    {
        
    	AlienE alin = new AlienE();
    	
    	AlienEName alEN = new AlienEName();
    	
    	alEN.setFirstName("J");
    	alEN.setMiddleName("Satya");
    	alEN.setLastName("Teja");
    	
    	
    	alin.setaId(5012);
    	alin.setaName(alEN);
    	alin.setColor("Green");
    	alin.setSalary(56000);
    	
    	Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(AlienE.class);
    	
    	ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
		
    	SessionFactory sf = con.buildSessionFactory(reg);
		  
    	Session session = sf.openSession();
		  
		Transaction tx = session.beginTransaction();
		  
		session.save(alin);
		 
    	tx.commit();
    }
}
