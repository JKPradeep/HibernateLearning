package com.kasi.HibDemo;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;



/**
 * Hello world!
 *
 */
public class AppFetch 
{
    public static void main( String[] args )
    {
        // System.out.println( "Hello World!" );
        
    	Alien aln = null;
    	
    	Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Alien.class);
    	
    	ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
		
    	SessionFactory sf = con.buildSessionFactory(reg);
		  
    	Session session = sf.openSession();
		  
		Transaction tx = session.beginTransaction();
		  
		aln = (Alien) session.get(Alien.class, 911);
		 
    	tx.commit();
    	
    	System.out.println(aln);
    }
}
