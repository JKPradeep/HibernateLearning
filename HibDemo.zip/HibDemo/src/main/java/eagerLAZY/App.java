/**
 * 
 */
package eagerLAZY;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

/**
 * @author JK Pradeep
 *
 */
public class App {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
//		Student stud1 = new Student();
//		stud1.setRollNo(301);
//		stud1.setName("kasi");
//		stud1.setMarks(40);
//		
//		List<Laptop> laptops1 = new ArrayList<Laptop>();
//		
//		Laptop laptop1 = new Laptop();
//		laptop1.setlId(1001);
//		laptop1.setlName("dell");
//		laptops1.add(laptop1);
//
//		Laptop laptop2 = new Laptop();
//		laptop2.setlId(1002);
//		laptop2.setlName("hp");
//		laptops1.add(laptop2);
//
//		
//		stud1.setLaptopsw(laptops1);
//		laptop1.setStudt(stud1);	
//		laptop2.setStudt(stud1);	
//
//		List<Laptop> laptops2 = new ArrayList<Laptop>();
//		
//		Laptop laptop3 = new Laptop();
//		laptop3.setlId(1005);
//		laptop3.setlName("Lenovo");
//		laptops2.add(laptop3);
//		
//		Laptop laptop4 = new Laptop();
//		laptop4.setlId(1006);
//		laptop4.setlName("apple");
//		laptops2.add(laptop4);
//		
//		Student stud2 = new Student();
//		stud2.setRollNo(401);
//		stud2.setName("Pradeep");
//		stud2.setMarks(60);
//		stud2.setLaptopsw(laptops2);
//		
//		laptop3.setStudt(stud2);
//		laptop4.setStudt(stud2);
		
		Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Laptop.class).addAnnotatedClass(Student.class);	
		ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
		SessionFactory sf = con.buildSessionFactory(reg);
		Session session = sf.openSession();
		
		Transaction tx = session.beginTransaction();
		
//		
//		session.save(laptop1);
//		session.save(laptop2);
//		session.save(laptop3);
//		session.save(laptop4);
//		
//		session.save(stud1);
//		session.save(stud2);

		Student s1 = session.get(Student.class, 401);
		
		System.out.println(s1.getName());
		
		
		/* Left Outer Join */
		
//		List<Laptop> laps = s1.getLaptopsw();
//		
//		for (Laptop l : laps) {
//			
//			System.out.println(l);
//		}
		
		tx.commit();
		
	}

}
