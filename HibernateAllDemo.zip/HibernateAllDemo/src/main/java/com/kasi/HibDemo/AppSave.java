package com.kasi.HibDemo;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;



/**
 * Hello world!
 *
 */
public class AppSave 
{
    public static void main( String[] args )
    {
        // System.out.println( "Hello World!" );
        
    	Alien aln = new Alien();
    	
    	aln.setaId(911);
    	aln.setaName("PradeeP11");
    	aln.setColor("Blue11");
    	aln.setSalary(11100);
    	
    	Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Alien.class);
    	
    	ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
		
    	SessionFactory sf = con.buildSessionFactory(reg);
		  
    	Session session = sf.openSession();
		  
		Transaction tx = session.beginTransaction();
		  
		session.save(aln);
		 
    	tx.commit();
    }
}
