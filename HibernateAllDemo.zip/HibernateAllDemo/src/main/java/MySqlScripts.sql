
create database login;

use login;

create table userDetails (uname varchar(20), passwors varchar(20));

select * from userDetails;

insert into userDetails values('kasi', '1234');
insert into userDetails values('satya', '7896');



CREATE DATABASE ALIENDB;

use ALIENDB;
show tables;

select * from alien;
select * from aleintable;
select * from aleintabel;
select * from aleinetable;

drop table aleinetable;
drop table aleintable;
drop table aleintabel;

select * from laptop;
select * from student;
select * from student_laptop;
select * from laptop_student;

drop table laptop;
drop table student;
drop table student_laptop;
drop table laptop_student;

create database laptopndb;

use laptopndb;

show tables;

select * from laptops;








