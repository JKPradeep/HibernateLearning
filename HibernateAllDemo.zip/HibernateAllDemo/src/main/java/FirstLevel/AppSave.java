package FirstLevel;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;



/**
 * Hello world!
 *
 */
public class AppSave 
{
    public static void main( String[] args )
    {
        // System.out.println( "Hello World!" );
        
    	Alien aln = new Alien();
    	
    	aln.setaId(914);
    	aln.setaName("JSTeja");
    	aln.setColor("White");
    	aln.setSalary(11400);
    	
    	Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Alien.class);
    	
    	ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
		
    	SessionFactory sf = con.buildSessionFactory(reg);
		  
    	Session session1 = sf.openSession();
		  
		Transaction tx1 = session1.beginTransaction();
		  
		session1.save(aln);
		 
    	tx1.commit();
    	

    }
}
