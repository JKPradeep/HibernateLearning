/**
 * 
 */
package GetVsLoad;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

/**
 * @author JK Pradeep
 *
 */
public class App {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Student.class);	
		ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
		SessionFactory sf = con.buildSessionFactory(reg);
		Session session = sf.openSession();
		
		Transaction tx = session.beginTransaction();

//		Student std = session.get(Student.class, 6);
//		System.out.println(std);
		
//		Student std = session.load(Student.class, 6);
//		System.out.println(std);
		
		
//		Student std = session.get(Student.class, 6);
		
//		Student std = session.load(Student.class, 6);
		
		
//		Student std = session.get(Student.class, 80234);
//		System.out.println(std);
		
		Student std = session.load(Student.class, 80234);
		System.out.println(std);
		
		
		tx.commit();

	}

}
