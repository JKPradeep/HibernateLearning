/**
 * 
 */
package HQL;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

/**
 * @author JK Pradeep
 *
 */
public class App {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Student.class);	
		ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
		SessionFactory sf = con.buildSessionFactory(reg);
		Session session = sf.openSession();
		
		Transaction tx = session.beginTransaction();


//		for (int i=1; i<=50; i++)
//		{
//			Random r = new Random();
//			
//			Student student = new Student();
//			student.setRollNo(i);
//			student.setName("name" +i);
//			student.setMarks(r.nextInt(100));
//			
//			session.save(student);
//		}
		

		
		
//		Query q = session.createQuery("from Student");
//		List<Student> students =   q.list();
//		
//		for(Student s : students)
//		{
//			System.out.println(s);
//			
//		}
		
		
		
//		Query q1 = session.createQuery("from Student where marks > 80");
//		List<Student> students =   q1.list();
//		
//		for(Student s : students)
//		{
//			System.out.println(s);
//			
//		}
		
		
//		Query q2 = session.createQuery("from Student where rollNo = 8");
//		Student studt =   (Student) q2.uniqueResult();
//		
//		System.out.println(studt);
			
		
//		Query q3 = session.createQuery("select rollNo, marks from Student where rollNo = 8");
//		Object[] st =   (Object[]) q3.uniqueResult();
//		
//		System.out.println(st[0]+ " "+st[1]);
		
		
//		Query q4 = session.createQuery("select rollNo, marks from Student");
//		List<Object[]> students =   (List<Object[]>) q4.list();
//		
//		for(Object[] std : students) 
//			System.out.println(std[0]+ " " + std[1]);
		
		
//		Query q5 = session.createQuery("select name, marks from Student");
//		List<Object[]> students =   (List<Object[]>) q5.list();
//		
//		for(Object[] std : students) 
//			System.out.println(std[0]+ " " + std[1]);
		
	
		
//		Query q6 = session.createQuery("select rollNo, marks from Student s where s.marks >80");
//		List<Object[]> students =   (List<Object[]>) q6.list();
//		
//		for(Object[] std : students) 
//			System.out.println(std[0]+ " " + std[1]);
		
		
//		Query q7 = session.createQuery("select sum(marks) from Student where marks >80");
//		Long tMarks =   (Long) q7.uniqueResult();
//		
//		System.out.println(tMarks);
		
//		int b = 80;
//		Query q8 = session.createQuery("select sum(marks) from Student where marks > :m");
//		q8.setParameter("m", b);
//		Long tMarks =   (Long) q8.uniqueResult();
//		
//		System.out.println(tMarks);
		

//		SQLQuery query = session.createSQLQuery("select * from student where marks >80");
//		query.addEntity(Student.class);
//		
//		List<Student> stds = query.list();
//		
//		for (Student s : stds)
//		{
//			System.out.println(s);
//		}
		
		
		SQLQuery query = session.createSQLQuery("select rollNo, marks from student where marks >80");
		
		query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
		
		List<Object> Students =   query.list();
		
		for (Object o : Students)
		{
			// System.out.println(o);
			
			Map m = (Map) o;
			System.out.println(m.get("rollNo") + " : " + m.get("marks"));
		}
		
			

		
		tx.commit();
		
	}

}
