/**
 * 
 */
package SecondLevelCacheWithQuery;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * @author JK Pradeep
 *
 */

//POJO

@Entity
@Table(name = "aleinTable")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class Alien {

	@Id
	private int aId;
	
	
	private String aName;
	
	@Column(name = "acolor")
	private String color;
	
	@Transient
	private int salary;

	
	public int getaId() {
		return aId;
	}

	public void setaId(int aId) {
		this.aId = aId;
	}

	public String getaName() {
		return aName;
	}

	public void setaName(String aName) {
		this.aName = aName;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	
	@Override
	public String toString() {
		return "Alien [aId=" + aId + ", aName=" + aName + ", color=" + color + ", salary=" + salary + "]";
	}


	
}
