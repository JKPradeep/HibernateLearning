package SecondLevelCacheWithQuery;



import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;



/**
 * Hello world!
 *
 */
public class AppFetch 
{
    public static void main( String[] args )
    {
        // System.out.println( "Hello World!" );
        
    	Alien aln = null;
    	
    	Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Alien.class);
    	
    	ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
		
    	SessionFactory sf = con.buildSessionFactory(reg);
		  
    	Session session1 = sf.openSession();
		Transaction tx1 = session1.beginTransaction();
		
		Query q1 = session1.createQuery("from Alien where aId = 911");
		q1.setCacheable(true);
		aln = (Alien) q1.uniqueResult();
		System.out.println(aln);
		    	
		tx1.commit();
    	session1.close();
    	
    	
    	Session session2 = sf.openSession();
		Transaction tx2 = session2.beginTransaction();
		Query q2 = session2.createQuery("from Alien where aId = 911");
		q2.setCacheable(true);
		aln = (Alien) q2.uniqueResult();
		System.out.println(aln);
    	tx2.commit();
    	session2.close();
    	
    	
    }
}
