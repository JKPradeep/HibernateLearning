/**
 * 
 */
package com.kasi.DemoHibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author JK Pradeep
 *
 */
@Entity
@Table(name = "lTablename")
public class Laptops {
	
	@Id
	private int lId;
	
	@Column(name = "lapCompalt")
	private String lCompany;

	public int getlId() {
		return lId;
	}

	public void setlId(int lId) {
		this.lId = lId;
	}

	public String getlCompany() {
		return lCompany;
	}

	public void setlCompany(String lCompany) {
		this.lCompany = lCompany;
	}

	
	public Laptops() {
		super();
	}

	@Override
	public String toString() {
		return "Laptop [lId=" + lId + ", lCompany=" + lCompany + "]";
	}
	
	

}
